import { useState, useEffect } from 'react';
import { startOfYear } from 'date-fns';
import JournalGrid from '@/components/JournalGrid';
import CollapsibleSidebar from '@/components/CollapsibleSidebar';
import { Button } from '@/components/ui/button';
import { Moon, Sun, BookOpen } from 'lucide-react';

export default function Journal() {
  const [visibleBlocks, setVisibleBlocks] = useState(30);
  const [startDate, setStartDate] = useState(startOfYear(new Date()));
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [journalEntries, setJournalEntries] = useState<Record<string, string>>({});
  const currentYear = new Date().getFullYear();

  // Load journal entries for preview
  useEffect(() => {
    const savedEntries = localStorage.getItem(`journal-entries-${currentYear}`);
    if (savedEntries) {
      try {
        setJournalEntries(JSON.parse(savedEntries));
      } catch (error) {
        console.error('Failed to load journal entries:', error);
      }
    }
  }, [currentYear]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div 
      className={`
        min-h-screen transition-all duration-500 ease-out
        bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100
        dark:from-slate-900 dark:via-slate-800 dark:to-slate-900
      `}
      data-testid="journal-page"
    >
      {/* Header */}
      <header className="sticky top-0 z-20 backdrop-blur-xl bg-white/20 dark:bg-black/20 border-b border-white/20">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/20 backdrop-blur-md rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground" data-testid="app-title">
                  365 Journal
                </h1>
                <p className="text-sm text-muted-foreground">
                  Your year in words
                </p>
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleDarkMode}
              className="hover-elevate"
              data-testid="button-theme-toggle"
            >
              {isDarkMode ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Collapsible Sidebar */}
      <CollapsibleSidebar
        visibleBlocks={visibleBlocks}
        onVisibleBlocksChange={setVisibleBlocks}
        startDate={startDate}
        onStartDateChange={setStartDate}
        totalBlocks={365}
        currentYear={currentYear}
        journalEntries={journalEntries}
      />

      {/* Main Content - Full Width */}
      <main className="w-full px-6 py-8">
        <div className="w-full">
          <JournalGrid
            visibleBlocks={visibleBlocks}
            startDate={startDate}
            year={currentYear}
            isDarkMode={isDarkMode}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 py-8 border-t border-white/20 bg-white/5 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-sm text-muted-foreground">
            Capture your thoughts, one day at a time. All entries are saved locally in your browser.
          </p>
        </div>
      </footer>
    </div>
  );
}
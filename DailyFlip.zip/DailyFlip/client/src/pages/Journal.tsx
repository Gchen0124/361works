import JournalBook from '@/components/JournalBook';
import ThemeToggle from '@/components/ThemeToggle';

export default function Journal() {
  return (
    <div className="relative w-full h-screen overflow-hidden">
      {/* Theme toggle in top right */}
      <div className="absolute top-6 right-6 z-30">
        <ThemeToggle />
      </div>

      {/* Main journal */}
      <JournalBook />
    </div>
  );
}
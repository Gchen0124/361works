import { useState } from 'react';
import { Button } from '@/components/ui/button';
import AISidePanel from '../AISidePanel';

export default function AISidePanelExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative w-full h-96 bg-gradient-to-br from-background to-muted/20 rounded-lg">
      <div className="p-8">
        <Button
          onClick={() => setIsOpen(true)}
          className="hover-elevate"
        >
          Open AI Panel
        </Button>
      </div>
      
      <AISidePanel
        isOpen={isOpen}
        question="What is the meaning of life"
        onClose={() => setIsOpen(false)}
      />
    </div>
  );
}
import JournalBook from '../JournalBook';

export default function JournalBookExample() {
  return <JournalBook />;
}
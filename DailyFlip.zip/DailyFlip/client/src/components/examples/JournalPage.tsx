import JournalPage from '../JournalPage';

export default function JournalPageExample() {
  const today = new Date();
  
  const handleContentChange = (content: string) => {
    console.log('Content changed:', content);
  };

  const handleQuestionDetected = (question: string) => {
    console.log('Question detected:', question);
  };

  return (
    <div className="h-96 w-80 bg-gradient-to-br from-background to-muted/20">
      <JournalPage
        date={today}
        content="Today was a wonderful day. I learned about React components and how to create beautiful user interfaces."
        onContentChange={handleContentChange}
        onQuestionDetected={handleQuestionDetected}
        isLeft={true}
      />
    </div>
  );
}
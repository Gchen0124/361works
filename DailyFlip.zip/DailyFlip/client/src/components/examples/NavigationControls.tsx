import NavigationControls from '../NavigationControls';

export default function NavigationControlsExample() {
  const handlePrevious = () => {
    console.log('Previous page clicked');
  };

  const handleNext = () => {
    console.log('Next page clicked');
  };

  return (
    <div className="relative w-96 h-64 bg-gradient-to-br from-background to-muted/20 rounded-lg">
      <NavigationControls
        onPrevious={handlePrevious}
        onNext={handleNext}
        canGoPrevious={true}
        canGoNext={true}
      />
    </div>
  );
}
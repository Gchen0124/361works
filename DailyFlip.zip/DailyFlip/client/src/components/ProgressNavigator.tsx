import { useState, useCallback } from 'react';
import { format, addDays, subDays } from 'date-fns';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

interface ProgressNavigatorProps {
  currentDate: Date;
  onDateChange: (date: Date) => void;
  totalDays?: number;
}

export default function ProgressNavigator({ 
  currentDate, 
  onDateChange,
  totalDays = 365 
}: ProgressNavigatorProps) {
  const [isQuickNav, setIsQuickNav] = useState(false);

  // Calculate position relative to start of year
  const startOfYear = new Date(currentDate.getFullYear(), 0, 1);
  const dayOfYear = Math.floor((currentDate.getTime() - startOfYear.getTime()) / (1000 * 60 * 60 * 24));
  
  const handlePrevious = useCallback(() => {
    onDateChange(subDays(currentDate, 2));
  }, [currentDate, onDateChange]);

  const handleNext = useCallback(() => {
    onDateChange(addDays(currentDate, 2));
  }, [currentDate, onDateChange]);

  const handleSliderChange = useCallback((value: number[]) => {
    const newDay = value[0];
    const newDate = addDays(startOfYear, newDay);
    onDateChange(newDate);
  }, [startOfYear, onDateChange]);

  const formatDateRange = () => {
    const leftDate = currentDate;
    const rightDate = addDays(currentDate, 1);
    return `${format(leftDate, 'MMM d')} - ${format(rightDate, 'MMM d, yyyy')}`;
  };

  return (
    <div className="flex flex-col items-center gap-4 p-6 bg-background/95 backdrop-blur-sm border border-border/50 rounded-lg shadow-lg">
      
      {/* Date display and quick nav toggle */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsQuickNav(!isQuickNav)}
          className="w-8 h-8 hover-elevate"
          data-testid="button-toggle-quick-nav"
        >
          <Calendar className="w-4 h-4" />
        </Button>
        
        <span className="font-serif text-lg font-medium text-foreground min-w-[200px] text-center" data-testid="text-date-range">
          {formatDateRange()}
        </span>
      </div>

      {/* Main navigation controls */}
      <div className="flex items-center gap-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={handlePrevious}
          className="w-12 h-12 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 shadow-lg hover-elevate"
          data-testid="button-previous-pages"
        >
          <ChevronLeft className="w-6 h-6" />
        </Button>

        {/* Progress bar - always visible but more prominent when in quick nav mode */}
        <div className={`flex items-center gap-2 transition-all duration-300 ${isQuickNav ? 'w-80' : 'w-48'}`}>
          <span className="text-xs text-muted-foreground">Jan</span>
          <div className="flex-1">
            <Slider
              value={[dayOfYear]}
              onValueChange={handleSliderChange}
              max={totalDays - 1}
              min={0}
              step={1}
              className="w-full"
              data-testid="slider-date-navigator"
            />
          </div>
          <span className="text-xs text-muted-foreground">Dec</span>
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={handleNext}
          className="w-12 h-12 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 shadow-lg hover-elevate"
          data-testid="button-next-pages"
        >
          <ChevronRight className="w-6 h-6" />
        </Button>
      </div>

      {/* Progress indicators */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span>Day {dayOfYear + 1} of {totalDays}</span>
        <span>•</span>
        <span>{Math.round(((dayOfYear + 1) / totalDays) * 100)}% of year</span>
      </div>
    </div>
  );
}
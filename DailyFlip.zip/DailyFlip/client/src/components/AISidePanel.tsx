import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { X, Sparkles, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';

interface AISidePanelProps {
  isOpen: boolean;
  question: string;
  onClose: () => void;
  context?: string;
}

export default function AISidePanel({ isOpen, question, onClose, context }: AISidePanelProps) {
  const [response, setResponse] = useState('');

  const askQuestionMutation = useMutation({
    mutationFn: (data: { question: string; context?: string }) =>
      apiRequest('/api/ai/question', {
        method: 'POST',
        body: data,
      }),
    onSuccess: (data) => {
      setResponse(data.response);
    },
    onError: (error) => {
      console.error('Error asking question:', error);
      setResponse('Sorry, I encountered an error while processing your question. Please try again.');
    },
  });

  const handleAskQuestion = async () => {
    if (!question.trim()) return;
    
    setResponse('');
    askQuestionMutation.mutate({
      question,
      context,
    });
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
        onClick={onClose}
      />
      
      {/* Side panel */}
      <div className="fixed right-0 top-0 h-full w-96 bg-background/95 backdrop-blur-lg border-l border-border/50 shadow-2xl z-50 transform transition-transform duration-300 ease-out">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border/20">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-lg text-foreground" data-testid="text-ai-panel-title">
              AI Assistant
            </h3>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="w-8 h-8 hover-elevate"
            data-testid="button-close-ai-panel"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="flex flex-col h-full p-6 space-y-4">
          
          {/* Question display */}
          <div className="p-4 bg-muted/50 rounded-lg border border-border/30">
            <p className="text-sm text-muted-foreground mb-1">Your Question:</p>
            <p className="text-foreground font-medium" data-testid="text-detected-question">
              {question}?
            </p>
          </div>

          {/* Ask button */}
          <Button
            onClick={handleAskQuestion}
            disabled={askQuestionMutation.isPending || !question.trim()}
            className="w-full gap-2 hover-elevate"
            data-testid="button-ask-ai"
          >
            <Send className="w-4 h-4" />
            {askQuestionMutation.isPending ? 'Thinking...' : 'Ask AI'}
          </Button>

          {/* Response area */}
          {response && (
            <div className="flex-1 p-4 bg-card/50 rounded-lg border border-card-border/50 overflow-y-auto">
              <p className="text-sm text-muted-foreground mb-2">AI Response:</p>
              <div className="prose prose-sm max-w-none text-foreground" data-testid="text-ai-response">
                {response}
              </div>
            </div>
          )}

          {/* Loading state */}
          {askQuestionMutation.isPending && (
            <div className="flex-1 flex items-center justify-center">
              <div className="flex items-center gap-2 text-muted-foreground">
                <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
                <span>AI is thinking...</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
import { useState, useCallback } from 'react';
import { format } from 'date-fns';

interface JournalPageProps {
  date: Date;
  content: string;
  onContentChange: (content: string) => void;
  onQuestionDetected: (question: string) => void;
  isLeft?: boolean;
}

export default function JournalPage({ 
  date, 
  content, 
  onContentChange, 
  onQuestionDetected, 
  isLeft = false 
}: JournalPageProps) {
  const [localContent, setLocalContent] = useState(content);

  const handleContentChange = useCallback((newContent: string) => {
    setLocalContent(newContent);
    onContentChange(newContent);
    
    // Check for questions ending with '?'
    const lines = newContent.split('\n');
    const lastLine = lines[lines.length - 1];
    if (lastLine.endsWith('?')) {
      const questionMatch = lastLine.match(/(.+)\?$/);
      if (questionMatch) {
        onQuestionDetected(questionMatch[1].trim());
      }
    }
  }, [onContentChange, onQuestionDetected]);

  const formattedDate = format(date, 'EEEE, MMMM do, yyyy');

  return (
    <div className={`relative h-full w-full bg-background border-r ${isLeft ? 'border-r-border/30' : 'border-l-border/30'} overflow-hidden`}>
      {/* Page with glassmorphic effect */}
      <div className="absolute inset-2 bg-card/90 backdrop-blur-sm rounded-lg shadow-lg border border-card-border/50 overflow-hidden">
        
        {/* Date header */}
        <div className="px-6 py-4 border-b border-border/20">
          <h2 className="text-lg font-serif font-semibold text-foreground/90" data-testid={`text-date-${isLeft ? 'left' : 'right'}`}>
            {formattedDate}
          </h2>
        </div>

        {/* Content area */}
        <div className="p-6 h-full">
          <textarea
            value={localContent}
            onChange={(e) => handleContentChange(e.target.value)}
            placeholder="Write your thoughts for today..."
            className="w-full h-full resize-none bg-transparent border-none outline-none text-foreground placeholder:text-muted-foreground font-sans text-base leading-relaxed focus:ring-0"
            data-testid={`input-journal-${isLeft ? 'left' : 'right'}`}
          />
        </div>

        {/* Page corner fold effect */}
        <div className="absolute top-2 right-2 w-4 h-4 bg-gradient-to-br from-transparent to-border/20 transform rotate-45"></div>
      </div>
    </div>
  );
}
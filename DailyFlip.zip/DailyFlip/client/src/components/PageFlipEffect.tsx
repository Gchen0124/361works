import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PageFlipEffectProps {
  children: React.ReactNode;
  isFlipping: boolean;
  direction: 'left' | 'right';
  onFlipComplete: () => void;
}

export default function PageFlipEffect({ 
  children, 
  isFlipping, 
  direction, 
  onFlipComplete 
}: PageFlipEffectProps) {
  const [flipProgress, setFlipProgress] = useState(0);

  useEffect(() => {
    if (isFlipping) {
      setFlipProgress(1);
      const timer = setTimeout(() => {
        setFlipProgress(0);
        onFlipComplete();
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [isFlipping, onFlipComplete]);

  return (
    <div className="relative w-full h-full preserve-3d">
      <motion.div
        className="absolute inset-0 w-full h-full"
        style={{
          transformStyle: 'preserve-3d',
        }}
        animate={{
          rotateY: isFlipping ? (direction === 'right' ? -180 : 180) : 0,
        }}
        transition={{
          duration: 0.6,
          ease: [0.25, 0.1, 0.25, 1],
        }}
      >
        {children}
      </motion.div>
    </div>
  );
}
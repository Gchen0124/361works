import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface NavigationControlsProps {
  onPrevious: () => void;
  onNext: () => void;
  canGoPrevious: boolean;
  canGoNext: boolean;
}

export default function NavigationControls({
  onPrevious,
  onNext,
  canGoPrevious,
  canGoNext
}: NavigationControlsProps) {
  return (
    <>
      {/* Previous button - left side */}
      <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20">
        <Button
          variant="ghost"
          size="icon"
          onClick={onPrevious}
          disabled={!canGoPrevious}
          className="w-12 h-12 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 shadow-lg hover-elevate"
          data-testid="button-previous-page"
        >
          <ChevronLeft className="w-6 h-6" />
        </Button>
      </div>

      {/* Next button - right side */}
      <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20">
        <Button
          variant="ghost"
          size="icon"
          onClick={onNext}
          disabled={!canGoNext}
          className="w-12 h-12 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 shadow-lg hover-elevate"
          data-testid="button-next-page"
        >
          <ChevronRight className="w-6 h-6" />
        </Button>
      </div>
    </>
  );
}
import { useState, useCallback } from 'react';
import { addDays, format } from 'date-fns';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import JournalPage from '@/components/JournalPage';
import ProgressNavigator from '@/components/ProgressNavigator';
import PageFlipEffect from '@/components/PageFlipEffect';
import AISidePanel from '@/components/AISidePanel';
import { apiRequest } from '@/lib/queryClient';

interface JournalEntry {
  id?: string;
  date: string;
  content: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export default function JournalBook() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showAIPanel, setShowAIPanel] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [isFlipping, setIsFlipping] = useState(false);
  const [flipDirection, setFlipDirection] = useState<'left' | 'right'>('right');
  const queryClient = useQueryClient();

  // Get the two consecutive dates to display
  const leftDate = currentDate;
  const rightDate = addDays(currentDate, 1);

  // Fetch journal entries for current dates
  const leftDateKey = format(leftDate, 'yyyy-MM-dd');
  const rightDateKey = format(rightDate, 'yyyy-MM-dd');

  const { data: leftEntry } = useQuery({
    queryKey: ['/api/journal', leftDateKey],
    queryFn: () => fetch(`/api/journal/${leftDateKey}`).then(res => res.json()),
  });

  const { data: rightEntry } = useQuery({
    queryKey: ['/api/journal', rightDateKey],
    queryFn: () => fetch(`/api/journal/${rightDateKey}`).then(res => res.json()),
  });

  // Mutation for saving entries
  const saveEntryMutation = useMutation({
    mutationFn: (entry: { date: string; content: string }) =>
      apiRequest('/api/journal', {
        method: 'POST',
        body: entry,
      }),
    onSuccess: (data, variables) => {
      // Update the cache with the new data
      queryClient.setQueryData(['/api/journal', variables.date], data);
    },
  });

  const getEntryContent = (date: Date) => {
    const dateKey = format(date, 'yyyy-MM-dd');
    if (dateKey === leftDateKey) return leftEntry?.content || '';
    if (dateKey === rightDateKey) return rightEntry?.content || '';
    return '';
  };

  const updateEntryContent = useCallback((date: Date, content: string) => {
    const dateKey = format(date, 'yyyy-MM-dd');
    
    // Save to backend
    saveEntryMutation.mutate({
      date: dateKey,
      content,
    });
  }, [saveEntryMutation]);

  const handleDateChange = useCallback((newDate: Date) => {
    if (newDate.getTime() !== currentDate.getTime()) {
      const direction = newDate > currentDate ? 'right' : 'left';
      setFlipDirection(direction);
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentDate(newDate);
        setIsFlipping(false);
      }, 300);
    }
  }, [currentDate]);

  const handleFlipComplete = () => {
    setIsFlipping(false);
  };

  const handleQuestionDetected = (question: string) => {
    setCurrentQuestion(question);
    setShowAIPanel(true);
  };

  const handleCloseAIPanel = () => {
    setShowAIPanel(false);
    setCurrentQuestion('');
  };

  return (
    <div className="relative w-full h-screen bg-gradient-to-br from-background via-muted/10 to-background overflow-hidden">
      
      {/* Progress Navigator - positioned at top */}
      <div className="absolute top-6 left-1/2 transform -translate-x-1/2 z-30">
        <ProgressNavigator
          currentDate={currentDate}
          onDateChange={handleDateChange}
        />
      </div>

      {/* Book container with perspective */}
      <div className="flex items-center justify-center h-full p-8 pt-32">
        <div className="relative w-full max-w-6xl h-full max-h-[700px]" style={{ perspective: '1000px' }}>
          
          {/* Open book with page flip effect */}
          <PageFlipEffect
            isFlipping={isFlipping}
            direction={flipDirection}
            onFlipComplete={handleFlipComplete}
          >
            <div className="relative w-full h-full bg-gradient-to-b from-background to-muted/20 rounded-lg shadow-2xl overflow-hidden" style={{ transformStyle: 'preserve-3d' }}>
              
              {/* Silver book binding in the center */}
              <div className="absolute left-1/2 top-0 w-4 h-full bg-gradient-to-b from-slate-300 to-slate-500 transform -translate-x-1/2 z-10 shadow-lg">
                <div className="w-full h-full bg-gradient-to-r from-slate-200/30 via-transparent to-slate-200/30"></div>
                {/* Binding details */}
                <div className="absolute inset-y-0 left-1/2 w-px bg-slate-600 transform -translate-x-1/2"></div>
              </div>

              {/* Left page */}
              <div className="absolute left-0 top-0 w-1/2 h-full">
                <JournalPage
                  date={leftDate}
                  content={getEntryContent(leftDate)}
                  onContentChange={(content) => updateEntryContent(leftDate, content)}
                  onQuestionDetected={handleQuestionDetected}
                  isLeft={true}
                />
              </div>

              {/* Right page */}
              <div className="absolute right-0 top-0 w-1/2 h-full">
                <JournalPage
                  date={rightDate}
                  content={getEntryContent(rightDate)}
                  onContentChange={(content) => updateEntryContent(rightDate, content)}
                  onQuestionDetected={handleQuestionDetected}
                  isLeft={false}
                />
              </div>

              {/* Subtle page edges for 3D effect */}
              <div className="absolute left-1/2 top-0 w-px h-full bg-border/20 transform -translate-x-1/2 z-5"></div>
            </div>
          </PageFlipEffect>
        </div>
      </div>

      {/* AI Side Panel */}
      <AISidePanel
        isOpen={showAIPanel}
        question={currentQuestion}
        onClose={handleCloseAIPanel}
        context={getEntryContent(leftDate) + ' ' + getEntryContent(rightDate)}
      />
    </div>
  );
}
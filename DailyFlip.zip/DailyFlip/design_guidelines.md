# Journal App Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern digital note-taking apps like Notion and Obsidian, combined with realistic book interfaces for an authentic journaling experience.

## Core Design Elements

### A. Color Palette
**Primary Colors:**
- Light Mode: 40 8% 96% (warm off-white background), 220 13% 18% (dark charcoal text)
- Dark Mode: 220 13% 18% (dark charcoal background), 40 8% 96% (light text)

**Accent Colors:**
- Book spine/binding: 30 25% 45% (warm brown leather)
- Page shadows: 220 10% 85% (soft gray for depth)

**Glassmorphism Elements:**
- Side panel background: 220 13% 95% with 80% opacity and backdrop blur
- Button overlays: White with 20% opacity and strong backdrop blur

### B. Typography
**Primary Font:** Inter (Google Fonts)
- Page content: 16px regular weight
- Date headers: 18px medium weight
- Side panel text: 14px regular weight

**Secondary Font:** Crimson Text (Google Fonts) for elegant journal-style headings

### C. Layout System
**Tailwind Spacing Primitives:** 2, 4, 6, 8, 12, 16
- Page margins: p-8
- Content spacing: gap-6, mb-4
- Button padding: px-6 py-2

### D. Component Library

**Open Book Layout:**
- Two-page spread with 3D perspective transform
- Each page: Fixed height with scroll overflow for long content
- Page divider with subtle shadow and binding detail
- Page corners with slight rounded edges (rounded-lg)

**Navigation Controls:**
- Floating glassmorphic buttons for page flipping
- Previous/Next arrows positioned outside book area
- Subtle hover animations with transform scale

**AI Side Panel:**
- Slides in from the right with smooth transition
- Glassmorphic background with strong backdrop blur
- Question detection indicator with gentle pulse animation
- Response area with typing animation effect

**Date Display:**
- Positioned at top of each page like traditional journal headers
- Elegant serif typography
- Subtle divider line below date

**Text Areas:**
- Invisible borders with focus states
- Seamless integration with page background
- Auto-resize functionality for long entries

### E. Interactions & Animations
- Page flip animation: 3D rotation with realistic timing
- Side panel entrance: Slide-in with backdrop fade
- Question mark detection: Subtle highlight of detected questions
- Minimal use of animations to maintain focus on content

## Visual Hierarchy
1. **Book Structure:** Dominant visual element with realistic depth
2. **Page Content:** Primary focus area with generous whitespace
3. **Navigation:** Secondary, non-intrusive positioning
4. **AI Panel:** Contextual overlay that doesn't compete with main content

## Responsive Considerations
- Desktop: Full open book layout
- Tablet: Slightly compressed book with maintained proportions
- Mobile: Single page view with swipe navigation (fallback)

This design creates an immersive journaling experience that feels both modern and timeless, leveraging glassmorphism for contemporary appeal while maintaining the intimate feel of a physical journal.
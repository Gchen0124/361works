import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export async function answerQuestion(question: string, context?: string): Promise<string> {
  if (!openai) {
    throw new Error("OpenAI API key not configured");
  }
  
  try {
    const prompt = context 
      ? `Based on this journal context: "${context}"\n\nPlease answer this question: ${question}`
      : `Please answer this question thoughtfully and helpfully: ${question}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025
      messages: [
        {
          role: "system",
          content: "You are a thoughtful assistant helping with journal reflections. Provide insightful, supportive responses that encourage self-reflection and growth."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_completion_tokens: 300,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response to your question.";
  } catch (error) {
    console.error("Error answering question:", error);
    throw new Error("Failed to get AI response");
  }
}
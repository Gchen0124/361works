import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertJournalEntrySchema } from "@shared/schema";
import { answerQuestion } from "./ai";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Journal entry routes
  
  // Get journal entry by date
  app.get("/api/journal/:date", async (req, res) => {
    try {
      const { date } = req.params;
      
      // Validate date format (YYYY-MM-DD)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.status(400).json({ error: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      const entry = await storage.getJournalEntry(date);
      
      if (!entry) {
        return res.json({ date, content: "" });
      }
      
      res.json(entry);
    } catch (error) {
      console.error("Error getting journal entry:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Create or update journal entry
  app.post("/api/journal", async (req, res) => {
    try {
      const validatedData = insertJournalEntrySchema.parse(req.body);
      const entry = await storage.createOrUpdateJournalEntry(validatedData);
      res.json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid data", details: error.errors });
      }
      console.error("Error saving journal entry:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get all journal entries
  app.get("/api/journal", async (req, res) => {
    try {
      const entries = await storage.getAllJournalEntries();
      res.json(entries);
    } catch (error) {
      console.error("Error getting journal entries:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // AI question answering
  app.post("/api/ai/question", async (req, res) => {
    try {
      const { question, context } = req.body;
      
      if (!question || typeof question !== 'string') {
        return res.status(400).json({ error: "Question is required" });
      }

      const response = await answerQuestion(question, context);
      res.json({ response });
    } catch (error) {
      console.error("Error processing AI question:", error);
      res.status(500).json({ error: "Failed to process question" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
